export default
    DATA = [
        {
            id: 0,
            name: "• Low",
        },
        {
            id: 1,
            name: "• Moderately Low",
        },
        {
            id: 2,
            name: "• Moderate",
        },
        {
            id: 3,
            name: "• Moderately High",
        },
        {
            id: 4,
            name: "• High",
        },
        {
            id: 4,
            name: "• Very High",
        },
    ];
