export default
    DATA = [
        {
            id: 0,
            name: "• Popularity",
        },
        {
            id: 1,
            name: "• Ratings-High to Low",
        },
        {
            id: 2,
            name: "• Returns-High to Low",
        },
    ];
