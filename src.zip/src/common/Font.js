export const font ={
    nunitoregular:"Nunito-Regular",
    nunitobold:"Nunito-Bold",
    nunitosemibold:"Nunito-SemiBold",
    montserratregular:"Montserrat-Regular",
    titilliumwebsemibold:"TitilliumWeb-SemiBold",
    poppinssemibold:"poppins_semibold",
    poppinsregular:"Poppins-Regular",
    poppinsmedium:'Poppins-Medium'


}