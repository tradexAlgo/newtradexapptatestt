export default
    DATA = [
        {
            id: 0,
            name: "• Aditya Birla Sun Life...",
        },
        {
            id: 1,
            name: "• Axis Mutual Fund",
        },
        {
            id: 2,
            name: "• BNP Paribas Mutual F...",
        },
        {
            id: 3,
            name: "• BOI AXA Mutual Fund",
        },
        {
            id: 4,
            name: "• Baroda Mutual Fund",
        },
        {
            id: 5,
            name: "• Canara Robeco Mutu",
        },
        {
            id: 6,
            name: "• DSP Mutual Fund",
        },
        {
            id: 7,
            name: "• Aditya Birla Sun Life...",
        },
        {
            id: 8,
            name: "• Axis Mutual Fund",
        },
        {
            id: 9,
            name: "• BNP Paribas Mutual F...",
        },
        {
            id: 10,
            name: "• BOI AXA Mutual Fund",
        },
        {
            id: 11,
            name: "• Baroda Mutual Fund",
        },
        {
            id: 12,
            name: "• Aditya Birla Sun Life...",
        },
    ];
