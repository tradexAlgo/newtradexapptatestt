const messages = {
  CONNECTION_ERROR: 'Please check your internet connection',
};

export default messages;
